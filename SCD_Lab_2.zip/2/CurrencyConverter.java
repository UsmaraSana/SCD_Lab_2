public class CurrencyConverter {
    private static final String[] c = {"USD", "PKR", "Pound", "Dirham", "INR", "BDT", "JPY"};
    private static final double[] er = {1.0, 236.0, 0.88, 3.67, 79.0, 104.0, 142.0};
    public static double convert(String baseCurr, double amount, String targetCurr) {
        int baseIndex = -1;
        int targetIndex = -1;
        for (int i = 0; i < c.length; i++) {
            if (c[i].equals(baseCurr)) {
                baseIndex = i;
            }
            if (c[i].equals(targetCurr)) {
                targetIndex = i;
            }
            if (baseIndex != -1 && targetIndex != -1) {
                break;
            }
        }
        if (baseIndex!=-1&&targetIndex!=-1) {
            double baseAmt = er[baseIndex];
            double targetAmt = er[targetIndex];
            double exchangedAmount = (amount/baseAmt)*targetAmt;
            return exchangedAmount;
        } else {
            System.out.println("Currency not found.");
            return -1.0;
        }
    }
    public static void main(String[] args) {
        double exchangeAmount = CurrencyConverter.convert("USD", 5.0, "PKR");
        if (exchangeAmount != -1.0) {
            System.out.println("Exchanged amount: " + exchangeAmount);
        }
        else
        System.out.println("Currency not found ");
    }
}
