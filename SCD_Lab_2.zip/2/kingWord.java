public class kingWord {
    public static void main(String[] args) {
        int size = 6; 
        int[][] k = new int[size][size];
        int[][] i = new int[size][size];
        int[][] n = new int[size][size];
        int[][] g = new int[size][size];
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                if ((col == 0) ||(col==size-1 && row==0)||(col==size-1&&row==size-1)||
                (row == size / 2 && col == 1)||(col==size-row*2 && row <= size / 2)||(col==size-3 && row >= size / 2 + 1 && row<size-1 )){
                    k[row][col] = 1;
                }
                if (col == size / 2) {
                    i[row][col] = 1;
                }
                if ((col+row!=0&& row==col)||(col==size-1)||(col==0)) {
                    n[row][col] = 1;
                }
                if ((col==0&&col+row!=0&&col+row!=size-1)||(row == 0 && col > 0 && col < size - 1) || (row == size - 1 && col > 0 && col < size - 1) || (col == 0 && row > 0 && row < size / 2) || (col == size - 1 && row > size / 2 && row < size - 1) || (row == size / 2 && col > size / 2 && col < size - 1) || (row > size / 2 && row < size - 1 && col == size - 1)) {
                    g[row][col] = 1;
                }
            }
        }
        printLetter(k);
        System.out.println();
        printLetter(i);
        System.out.println();
        printLetter(n);
        System.out.println();
        printLetter(g);
    }
    public static void printLetter(int[][] letter) {
        for (int row = 0; row < letter.length; row++) {
            for (int col = 0; col < letter[row].length; col++) {
                if (letter[row][col] == 1) {
                    System.out.print("1 ");
                } else {
                    System.out.print("0 ");
                }
            }
            System.out.println();
        }
    }
}
