public class first_lab2 {
    void add(int a,int b){
            int c=a+b;
            System.out.println("The sum of the integer numbers is : "+ c);
        }
    void add(double a,double b){
            double c=a+b;
            System.out.println("The sum of the float numbers is : "+ c);
        } 
    void add(char a,char b){
            float c=a+b;
            System.out.println("The sum of the characters is : "+ c);
        } 
    void add(String a,String b){
        try{double num1 = Double.parseDouble(a); 
            double num2 = Double.parseDouble(b);   
            double num=num1+num2;
            System.out.println("The sum of the strings is : "+ num);}
            catch (NumberFormatException e) {
                System.err.println("Invalid input: Both input strings must be valid numeric values.");
            }
        } 
    void add(int []arr){
        int a=0;
        for(int i=0;i<arr.length;i++){
            a+=arr[i];
        }
         System.out.println("The sum of the numbers in integer array is : "+ a);
    }
    void add(String []arr){ 
        double sum=0;
        double num=0;
        try{ for(int i=0;i<arr.length;i++){
            num=Double.parseDouble(arr[i]);
            sum=sum+num;
        }
         System.out.println("The sum of the numbers in String array is : "+ sum);}
         catch (NumberFormatException e) {
            System.err.println("Invalid input: Both input strings must be valid numeric values.");
        }
    }
    public static void main(String[] args) {
        first_lab2 a=new first_lab2();
        a.add(1,2);
        a.add(1.5,2.5);
        a.add('a','b');
        a.add("1","5");
        int[]array= {1,2};
        a.add(array);
        String[] strarray={"1","2","5"};
         a.add(strarray);
}
}