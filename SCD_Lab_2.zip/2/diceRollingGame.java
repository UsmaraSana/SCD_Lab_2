import java.util.Random;
public class diceRollingGame {
    public static void main(String[] args) {
        int[][] board = new int[10][10];
        Random random = new Random();
        int iteration = 1;
        int xColumn = 0;
        int row = 0;
        while (xColumn < 9 && row<9) {
            int diceRoll = random.nextInt(6)+1;
            System.out.println(iteration + " Iteration (Number generated: " + diceRoll + ")");
            board[row][xColumn] = 0;
            if(iteration==1){
                xColumn = diceRoll+(xColumn-1);
            }
            else{xColumn += diceRoll;}
            if (xColumn >= 10) {
                xColumn = (xColumn%10);
                row++;
            }
            board[row][xColumn] = 1;
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    if (board[i][j] == 1) {
                        System.out.print("x ");
                    } else {
                        System.out.print("0 ");
                    }
                }
                System.out.println();
            }
            System.out.println();
            iteration++;
        }
    }
}
